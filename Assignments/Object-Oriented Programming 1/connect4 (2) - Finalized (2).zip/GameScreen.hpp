#ifndef GAMESCREEN_HPP
#define GAMESCREEN_HPP

#include <graphics.h>
#include <cstring>
#include "Player.hpp"
#include "Button.hpp"

class GameScreen {
private:
    int board[6][7];
    Player* players[2];
    int currentPlayer;
    bool isPvC;

    void drawBoard();
    bool checkVictory();
    void displayVictory();
    void resetGame();
    void highlightWinningDiscs();
    
public:
    GameScreen(bool isPvC = false);
    ~GameScreen();
    void display();
    void handleInput(int x, int y);
};

#endif