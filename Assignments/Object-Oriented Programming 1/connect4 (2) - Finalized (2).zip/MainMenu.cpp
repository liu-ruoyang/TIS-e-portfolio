#include "MainMenu.hpp"

//constructor
MainMenu::MainMenu() : buttons{
    Button(50, 300, 200, 50, "Exit Game"),
    Button(300, 300, 200, 50, "PvP"),
    Button(550, 300, 200, 50, "PvC"),
    Button(50, 400, 700, 50, "Help")
} {}

// display main menu and draw buttons
void MainMenu::display() {
    cleardevice();
    readimagefile("1.bmp", 50, 50, 250, 250);
    readimagefile("2.bmp", 550, 50, 750, 250);
    setbkcolor(WHITE);
    setcolor(BLACK);
    settextstyle(TRIPLEX_FONT, HORIZ_DIR, 6);
    outtextxy(120, 100, "E-CONNECT 4");
    for (int i = 0; i < 4; i++) {
        buttons[i].draw();
    }
}

// check if button clicked
int MainMenu::handleClick(int mouseX, int mouseY) {
    for (int i = 0; i < 4; i++) {
        if (buttons[i].isClicked(mouseX, mouseY)) return i;
    }
    return -1;
}