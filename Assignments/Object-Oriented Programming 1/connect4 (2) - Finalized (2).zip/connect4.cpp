#include <graphics.h>
#include "MainMenu.hpp"
#include "GameScreen.hpp"
#include "HelpScreen.hpp"

int main() {
    initwindow(800, 600);
    MainMenu menu;
    GameScreen gamePvP(false), gamePvC(true);
    HelpScreen helpScreen;
    int state = 0;
    int menuDrawCount = 0;

    // run a loop until game exited
    while (true) {
        delay(50);
        // main menu
        if (state == 0) {
            //draw 3 times to ensure correctly loaded
            if (menuDrawCount < 3) {
                cleardevice();
                menu.display();
                menuDrawCount++;
            }
            if (ismouseclick(WM_LBUTTONDOWN)) {
                int x = mousex(), y = mousey();
                clearmouseclick(WM_LBUTTONDOWN);
                // check button clicked
                int action = menu.handleClick(x, y);
                if (action == 0) exit(0); //exit game
                if (action == 1) { //PvP
                    state = 1;
                    cleardevice();
                    gamePvP.display();
                }
                if (action == 2) { //PvC
                    state = 2;
                    cleardevice();
                    gamePvC.display();
                }
                if (action == 3) { //Helps
                    state = 3;
                    cleardevice();
                    helpScreen.display();
                }
            }
        } 
        // PvP mode
        else if (state == 1) {
            if (ismouseclick(WM_LBUTTONDOWN)) {
                int x = mousex(), y = mousey();
                clearmouseclick(WM_LBUTTONDOWN);
                gamePvP.handleInput(x, y);
            }
        } 
        // PvC mode
        else if (state == 2) {
            if (ismouseclick(WM_LBUTTONDOWN)) {
                int x = mousex(), y = mousey();
                clearmouseclick(WM_LBUTTONDOWN);
                gamePvC.handleInput(x, y);
            }
        } 
        // Help
        else if (state == 3) {
            if (ismouseclick(WM_LBUTTONDOWN)) {
                int x = mousex(), y = mousey();
                clearmouseclick(WM_LBUTTONDOWN);
                if (helpScreen.handleBack(x, y)) {
                    state = 0;
                    menuDrawCount = 0;
                }
            }
        }
    }

    closegraph();//close graph window
    return 0;
}