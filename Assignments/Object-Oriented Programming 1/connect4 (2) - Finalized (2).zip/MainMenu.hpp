#ifndef MAINMENU_HPP
#define MAINMENU_HPP

#include <graphics.h>
#include <cstring>
#include "Button.hpp"

class MainMenu {
private:
    Button buttons[4];

public:
    MainMenu();
    void display();
    int handleClick(int mouseX, int mouseY);
};

#endif