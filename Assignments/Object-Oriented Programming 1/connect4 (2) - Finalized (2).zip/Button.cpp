#include "Button.hpp"

// constructor: Initializes the Button object with position, size, and label.
Button::Button(int x, int y, int width, int height, const char* label) {
    this->x = x;
    this->y = y;
    this->width = width;
    this->height = height;
    strcpy(this->label, label);
}

// draws the button on the screen
void Button::draw() {
    setcolor(BLACK);
    setlinestyle(SOLID_LINE, 0, THICK_WIDTH);
    rectangle(x, y, x + width, y + height);
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 2);
    setbkcolor(WHITE);
    setcolor(BLACK);
    outtextxy(x + 10, y + 10, label);
}

// check if mouseclick is within the button boundary
bool Button::isClicked(int mouseX, int mouseY) {
    return (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height);
}