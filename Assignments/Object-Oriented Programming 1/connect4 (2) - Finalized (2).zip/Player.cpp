#include "Player.hpp"

// constructor
Player::Player(const char* name, int id) {
    strcpy(this->name, name);
    this->id = id;
}

HumanPlayer::HumanPlayer(const char* name, int id) : Player(name, id) {}

// display whose turn is it
void HumanPlayer::displayTurn() {
    setbkcolor(WHITE);
    setcolor(BLACK);
    rectangle(10, 10, 250, 50);
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 2);
    char message[50];
    sprintf(message, "Player %d's Turn (%s)", id, name);
    outtextxy(20, 20, message);
}

AIPlayer::AIPlayer(const char* name, int id) : Player(name, id) {}

// display whose turn is it
void AIPlayer::displayTurn() {
    setbkcolor(WHITE);
    setcolor(BLACK);
    rectangle(10, 10, 250, 50);
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 2);
    char message[50];
    sprintf(message, "Player %d's Turn (%s)", id, name);
    outtextxy(20, 20, message);
}

// determine move for AI player
int AIPlayer::getMove(int board[6][7]) {

    // winning
    for (int col = 0; col < 7; col++) {
        if (canWinNextMove(board, 3 - id, col)) {
            return col;
        }
    }

    // blocking
    for (int col = 0; col < 7; col++) {
        if (canWinNextMove(board, id, col)) {
            return col;
        }
    }

    // take center if not occupied
    if (isColumnPlayable(board, 3)) {
        return 3;
    }

    // place disc in first available column
    for (int col = 0; col < 7; col++) {
        if (isColumnPlayable(board, col)) {
            return col;
        }
    }

    return -1;
}

// check if the move result in a win
bool AIPlayer::canWinNextMove(int board[6][7], int playerID, int col) {
    if (!isColumnPlayable(board, col)) {
        return false;
    }

    int row = findAvailableRow(board, col);
    board[row][col] = playerID;

    bool victory = checkVictory(board, playerID);

    board[row][col] = 0;

    return victory;
}

// check if there's vacancy in acolumn
bool AIPlayer::isColumnPlayable(int board[6][7], int col) {
    return board[0][col] == 0;
}

// find first available row
int AIPlayer::findAvailableRow(int board[6][7], int col) {
    for (int row = 5; row >= 0; row--) {
        if (board[row][col] == 0) {
            return row;
        }
    }
    return -1;
}

// check if victory conditions satisfied
bool AIPlayer::checkVictory(int board[6][7], int playerID) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] == playerID &&
                board[i][j + 1] == playerID &&
                board[i][j + 2] == playerID &&
                board[i][j + 3] == playerID) {
                return true;
            }
        }
    }

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 7; j++) {
            if (board[i][j] == playerID &&
                board[i + 1][j] == playerID &&
                board[i + 2][j] == playerID &&
                board[i + 3][j] == playerID) {
                return true;
            }
        }
    }

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] == playerID &&
                board[i + 1][j + 1] == playerID &&
                board[i + 2][j + 2] == playerID &&
                board[i + 3][j + 3] == playerID) {
                return true;
            }
        }
    }

    for (int i = 0; i < 3; i++) {
        for (int j = 3; j < 7; j++) {
            if (board[i][j] == playerID &&
                board[i + 1][j - 1] == playerID &&
                board[i + 2][j - 2] == playerID &&
                board[i + 3][j - 3] == playerID) {
                return true;
            }
        }
    }
    return false;
}