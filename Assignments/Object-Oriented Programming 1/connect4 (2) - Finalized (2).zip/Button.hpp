#ifndef BUTTON_HPP
#define BUTTON_HPP

#include <graphics.h>
#include <cstring>

class Button {
private:
    int x, y, width, height;
    char label[50];

public:
    Button(int x, int y, int width, int height, const char* label);
    void draw();
    bool isClicked(int mouseX, int mouseY);
};

#endif