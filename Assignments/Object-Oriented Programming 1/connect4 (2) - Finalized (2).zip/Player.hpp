#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <graphics.h>
#include <cstring>

class Player {
protected:
    char name[20];
    int id;

public:
    Player(const char* name, int id);
    virtual void displayTurn() = 0;
};

class HumanPlayer : public Player {
public:
    HumanPlayer(const char* name, int id);
    void displayTurn() override;
};

class AIPlayer : public Player {
public:
    AIPlayer(const char* name, int id);
    void displayTurn() override;
    int getMove(int board[6][7]);

private:
    bool canWinNextMove(int board[6][7], int playerID, int col);
    bool isColumnPlayable(int board[6][7], int col);
    int findAvailableRow(int board[6][7], int col);
    bool checkVictory(int board[6][7], int playerID);
};

#endif
