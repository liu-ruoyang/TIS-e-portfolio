#ifndef HELPSCREEN_HPP
#define HELPSCREEN_HPP

#include <graphics.h>
#include "Button.hpp"

class HelpScreen {
private:
    Button backButton;

public:
    HelpScreen();
    void display();
    bool handleBack(int x, int y);
};

#endif