#include "GameScreen.hpp"

// initializes the GameScreen with player objects based on game mode (PvP or PvC)
GameScreen::GameScreen(bool isPvC) : isPvC(isPvC) {
    memset(board, 0, sizeof(board));
    players[0] = new HumanPlayer("Player 1", 1);
    players[1] = isPvC ? dynamic_cast<Player*>(new AIPlayer("Computer", 2)) 
        : dynamic_cast<Player*>(new HumanPlayer("Player 2", 2));
    currentPlayer = 0;
}

// destructor
GameScreen::~GameScreen() {
    delete players[0];
    delete players[1];
}

// clears the screen and draws the current state of the game board and player's turn
void GameScreen::display() {
    cleardevice();
    drawBoard();
    players[currentPlayer]->displayTurn();
}

// handles user input for placing a disc, updates the board, and checks for victory or draw
void GameScreen::handleInput(int x, int y) {
    int startX = 150;
    int startY = 100;
    if (x < startX || x > startX + 7 * 50 || y < startY || y > startY + 6 * 50) return;
    int col = (x - startX) / 50;
    for (int row = 5; row >= 0; row--) {
        if (board[row][col] == 0) {
            board[row][col] = currentPlayer + 1;
            if (checkVictory()) {
                display();
                highlightWinningDiscs();
                delay(3000);
                displayVictory();
                return;
            }
            bool isDraw = true;
            for (int col = 0; col < 7; col++) {
                if (board[0][col] == 0) {
                    isDraw = false;
                    break;
                }
            }
            if (isDraw) {
                display();
                displayVictory();
                return;
            }
            currentPlayer = 1 - currentPlayer;
            display();
            if (isPvC && currentPlayer == 1) {
                AIPlayer* ai = dynamic_cast<AIPlayer*>(players[1]);
                if (ai) {
                    delay(1000);
                    int aiCol = ai->getMove(board);
                    for (int aiRow = 5; aiRow >= 0; aiRow--) {
                        if (board[aiRow][aiCol] == 0) {
                            board[aiRow][aiCol] = currentPlayer + 1;
                            if (checkVictory()) {
                                display();
                                highlightWinningDiscs();
                                delay(3000);
                                displayVictory();
                                return;
                            }
                            isDraw = true;
                            for (int col = 0; col < 7; col++) {
                                if (board[0][col] == 0) {
                                    isDraw = false;
                                    break;
                                }
                            }
                            if (isDraw) {
                                display();
                                displayVictory();
                                return;
                            }
                            currentPlayer = 1 - currentPlayer;
                            display();
                            break;
                        }
                    }
                }
            }
            break;
        }
    }
}


//Draws a 6*7 gaming board and its current state, including player discs.
void GameScreen::drawBoard() {
    setbkcolor(WHITE);
    setcolor(BLACK);
    int startX = 150; 
    int startY = 100; 
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 7; j++) {
            int x = startX + j * 50;
            int y = startY + i * 50;
            rectangle(x, y, x + 50, y + 50); 
            if (board[i][j] != 0) {
                setfillstyle(SOLID_FILL, (board[i][j] == 1) ? DARKGRAY : LIGHTGREEN);
                fillellipse(x + 25, y + 25, 20, 20);
            }
        }
    }

    if (!isPvC) {
        readimagefile("3.bmp", 500, 100, 700, 400);
    } else {
        readimagefile("4.bmp", 500, 100, 700, 400);
    }

    setfillstyle(SOLID_FILL, LIGHTGRAY);
    fillellipse(650, 50, 10, 10); 
    setcolor(BLACK);
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 1);
    outtextxy(665, 43, ": Player 1");

    setfillstyle(SOLID_FILL, LIGHTGREEN);
    fillellipse(650, 80, 10, 10); 
    outtextxy(665, 73, ": Player 2");
}

// highlight the 4 connected discs
void GameScreen::highlightWinningDiscs() {
    setcolor(RED);
    setlinestyle(SOLID_LINE, 0, THICK_WIDTH);
    int startX = 150;
    int startY = 100;

    // check rows for victory and draw a line
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i][j + 1] &&
                board[i][j] == board[i][j + 2] &&
                board[i][j] == board[i][j + 3]) {
                for (int k = 0; k < 4; k++) {
                    int x = startX + (j + k) * 50 + 25;
                    int y = startY + i * 50 + 25;
                    if (k > 0) line(x - 50, y, x, y);
                }
                return;
            }
        }
    }

    // check columns for victory and draw a line
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 7; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i + 1][j] &&
                board[i][j] == board[i + 2][j] &&
                board[i][j] == board[i + 3][j]) {
                for (int k = 0; k < 4; k++) {
                    int x = startX + j * 50 + 25;
                    int y = startY + (i + k) * 50 + 25;
                    if (k > 0) line(x, y - 50, x, y);
                }
                return;
            }
        }
    }

    // check diagonals (top-left to bottom-right) for victory and draw a line
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i + 1][j + 1] &&
                board[i][j] == board[i + 2][j + 2] &&
                board[i][j] == board[i + 3][j + 3]) {
                for (int k = 0; k < 4; k++) {
                    int x = startX + (j + k) * 50 + 25;
                    int y = startY + (i + k) * 50 + 25;
                    if (k > 0) line(x - 50, y - 50, x, y);
                }
                return;
            }
        }
    }

    // check diagonals (bottom-left to top-right) for victory and draw a line
    for (int i = 3; i < 6; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i - 1][j + 1] &&
                board[i][j] == board[i - 2][j + 2] &&
                board[i][j] == board[i - 3][j + 3]) {
                for (int k = 0; k < 4; k++) {
                    int x = startX + (j + k) * 50 + 25;
                    int y = startY + (i - k) * 50 + 25;
                    if (k > 0) line(x - 50, y + 50, x, y);
                }
                return;
            }
        }
    }
}

// simply check if Victory conditions satisfied
bool GameScreen::checkVictory() {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i][j + 1] &&
                board[i][j] == board[i][j + 2] &&
                board[i][j] == board[i][j + 3]) {
                return true;
            }
        }
    }

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 7; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i + 1][j] &&
                board[i][j] == board[i + 2][j] &&
                board[i][j] == board[i + 3][j]) {
                return true;
            }
        }
    }

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i + 1][j + 1] &&
                board[i][j] == board[i + 2][j + 2] &&
                board[i][j] == board[i + 3][j + 3]) {
                return true;
            }
        }
    }

    for (int i = 3; i < 6; i++) {
        for (int j = 0; j < 4; j++) {
            if (board[i][j] != 0 &&
                board[i][j] == board[i - 1][j + 1] &&
                board[i][j] == board[i - 2][j + 2] &&
                board[i][j] == board[i - 3][j + 3]) {
                return true;
            }
        }
    }
    return false;
}

// display Victory or Draw page and provide 2 choices
void GameScreen::displayVictory() {
    // Check for draw condition
    bool isDraw = true;
    for (int col = 0; col < 7; col++) {
        if (board[0][col] == 0) {
            isDraw = false;
            break;
        }
    }

    cleardevice();
    setbkcolor(WHITE);
    setcolor(BLACK);
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 4);

    if (isDraw && !checkVictory()) {
        // Display draw message if board is full and no victory condition
        outtextxy(200, 100, "It's a Draw!");
    } 
    else {
        // Display victory message
        char victoryMessage[50];
        sprintf(victoryMessage, "Player %d Wins!", currentPlayer + 1);
        outtextxy(200, 100, victoryMessage);

        // Skip showing victory images for draw condition
        if (!isDraw) {
            if (currentPlayer == 0) {
                readimagefile("5.bmp", 550, 100, 750, 300);
            } 
            else {
                readimagefile("6.bmp", 550, 100, 750, 300);
            }
        }
    }

    Button playAgain(100, 300, 200, 50, "Play Again");
    Button exitGame(400, 300, 200, 50, "Exit Game");
    playAgain.draw();
    exitGame.draw();

    while (true) {
        delay(30);
        if (ismouseclick(WM_LBUTTONDOWN)) {
            int x = mousex(), y = mousey();
            clearmouseclick(WM_LBUTTONDOWN);

            if (playAgain.isClicked(x, y)) {
                resetGame();
                return;
            }
            if (exitGame.isClicked(x, y)) exit(0);
        }
    }
}


// reset to start a new game
void GameScreen::resetGame() {
    memset(board, 0, sizeof(board));
    currentPlayer = 0;
    display();
}