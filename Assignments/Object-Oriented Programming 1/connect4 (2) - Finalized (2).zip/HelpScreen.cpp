#include "HelpScreen.hpp"

// constructor
HelpScreen::HelpScreen() : backButton(550, 20, 150, 50, "Back") {}

// display help and draw a back button
void HelpScreen::display() {
    cleardevice();
    readimagefile("help.bmp", 0, 60, 800, 550);
    backButton.draw();
}

// check if the button is clicked
bool HelpScreen::handleBack(int x, int y) {
    return backButton.isClicked(x, y);
}